@javax.xml.bind.annotation.XmlSchema(namespace = "http://chatserver/")
package client;
